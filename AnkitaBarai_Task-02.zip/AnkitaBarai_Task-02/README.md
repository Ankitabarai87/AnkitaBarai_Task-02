# 🧺 Laundry Mart Webpage- Task-02

A simple and responsive laundry service webpage built using HTML as part of my assignment-Task-02. This project showcases a clean layout for a local laundry business, including services, pricing, and a basic booking form.

---

## 🚀 Features

- 🧼 List of laundry services
- 💰 Simple price list table
- 📅 Booking form (Name, Email, Phone)
- 🖼️ Clean and simple layout
- 📱 Beginner-friendly structure

---

## 🛠️ Technologies Used

- HTML5

---

## ▶️ How to Run

1. Download the project  
2. Open the project folder  
3. Double-click on `index.html`  
   OR  
   Right-click → Open with Browser  

---

## 🎯 Purpose

This project is built to practice basic web development skills like structuring a webpage using HTML tags and attributes.

